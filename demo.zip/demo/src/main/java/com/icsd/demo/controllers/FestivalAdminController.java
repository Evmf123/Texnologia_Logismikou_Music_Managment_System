package com.icsd.demo.controllers;

import com.icsd.demo.models.Festival;
import com.icsd.demo.services.FestivalServiceExtended;
import org.springframework.web.bind.annotation.*;

// Αυτή η κλάση είναι Controller για διαχειριστικές λειτουργίες των Φεστιβάλ.
// Περιέχει endpoints που αλλάζουν την κατάσταση (state) ενός φεστιβάλ
// στη ροή από την δημιουργία μέχρι την ανακοίνωση.
@RestController
@RequestMapping("/api/admin/festivals")
public class FestivalAdminController {

    // Service που περιέχει την επιχειρησιακή λογική για τα φεστιβάλ
    private final FestivalServiceExtended festivalService;

    // Constructor injection: η Spring δίνει το FestivalServiceExtended
    public FestivalAdminController(FestivalServiceExtended festivalService) {
        this.festivalService = festivalService;
    }

    // TRANSITIONS ΤΟΥ ΦΕΣΤΙΒΑΛ 

    // Ξεκινάει τη φάση "Υποβολής Συμμετοχών" (CREATED -> SUBMISSION)
    @PostMapping("/{id}/startSubmission")
    public Festival startSubmission(@RequestHeader("X-User") String username, @PathVariable Long id) {
        // Καλεί το service για να αλλάξει την κατάσταση του φεστιβάλ
        return festivalService.startSubmission(id, username);
    }

    // Ξεκινάει τη φάση "Ανάθεσης σε προσωπικό" (SUBMISSION -> ASSIGNMENT)
    @PostMapping("/{id}/startAssignment")
    public Festival startAssignment(@RequestHeader("X-User") String username, @PathVariable Long id) {
        return festivalService.startAssignment(id, username);
    }

    // Ξεκινάει τη φάση "Αξιολόγησης" (ASSIGNMENT -> REVIEW)
    @PostMapping("/{id}/startReview")
    public Festival startReview(@RequestHeader("X-User") String username, @PathVariable Long id) {
        return festivalService.startReview(id, username);
    }

    // Ξεκινάει τη φάση "Δημιουργίας Προγράμματος" (REVIEW -> SCHEDULING)
    @PostMapping("/{id}/startScheduling")
    public Festival startScheduling(@RequestHeader("X-User") String username, @PathVariable Long id) {
        return festivalService.startScheduling(id, username);
    }

    // Ξεκινάει τη φάση "Τελικής Υποβολής" (SCHEDULING -> FINAL_SUBMISSION)
    @PostMapping("/{id}/startFinalSubmission")
    public Festival startFinalSubmission(@RequestHeader("X-User") String username, @PathVariable Long id) {
        return festivalService.startFinalSubmission(id, username);
    }

    // Ξεκινάει τη φάση "Τελικής Απόφασης" (FINAL_SUBMISSION -> DECISION)
    @PostMapping("/{id}/startDecision")
    public Festival startDecision(@RequestHeader("X-User") String username, @PathVariable Long id) {
        return festivalService.startDecision(id, username);
    }

    // Ανακοίνωση του φεστιβάλ (DECISION -> ANNOUNCED)
    // Σε αυτό το στάδιο το φεστιβάλ "κλειδώνει" και ανακοινώνεται επίσημα
    @PostMapping("/{id}/announce")
    public Festival announce(@RequestHeader("X-User") String username, @PathVariable Long id) {
        return festivalService.announceFestival(id, username);
    }
}
