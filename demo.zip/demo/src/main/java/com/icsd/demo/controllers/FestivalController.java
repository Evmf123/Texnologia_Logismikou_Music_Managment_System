package com.icsd.demo.controllers;

import com.icsd.demo.models.*;
import com.icsd.demo.services.FestivalService;
import com.icsd.demo.repositories.FestivalUserRoleRepository;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;

/**
 * Controller για βασικές λειτουργίες φεστιβάλ (δημιουργία και εμφάνιση).
 * Η "αυθεντικοποίηση" εδώ προσομοιώνεται με το custom header X-User.
 */
@RestController
@RequestMapping("/api/festivals")
public class FestivalController {

    // Service με την επιχειρησιακή λογική για φεστιβάλ
    private final FestivalService festivalService;

    // Repository για ρόλους χρηστών μέσα στα φεστιβάλ
    private final FestivalUserRoleRepository roleRepository;

    // Constructor injection: Η Spring περνάει τα service/repository
    public FestivalController(FestivalService festivalService, FestivalUserRoleRepository roleRepository) {
        this.festivalService = festivalService;
        this.roleRepository = roleRepository;
    }

    //  ENDPOINTS 

    // Endpoint για δημιουργία νέου φεστιβάλ
    // Δέχεται τον χρήστη από το header X-User και τα στοιχεία του φεστιβάλ από το σώμα (JSON).
    @PostMapping
    public Festival createFestival(@RequestHeader("X-User") String username,
                                   @RequestBody FestivalCreateRequest req) {
        // Καλεί το service για δημιουργία φεστιβάλ με όνομα, περιγραφή, τοποθεσία και δημιουργό
        return festivalService.createFestival(req.getName(), req.getDescription(), req.getVenue(), username);
    }

    // Endpoint για εμφάνιση συγκεκριμένου φεστιβάλ
    // Παίρνει το id από το URL και προαιρετικά το username από το header.
    @GetMapping("/{id}")
    public Festival viewFestival(@RequestHeader(value="X-User", required=false) String username,
                                 @PathVariable Long id) {
        // Αναζητά το φεστιβάλ με το id
        Optional<Festival> f = festivalService.findById(id);
        // Αν δεν βρεθεί, ρίχνει εξαίρεση
        return f.orElseThrow(() -> new IllegalArgumentException("Festival not found"));
    }

    // DTO (Data Transfer Object)

    // Εσωτερική στατική κλάση για το request δημιουργίας φεστιβάλ
    // Περιέχει μόνο τα απαραίτητα πεδία που στέλνει ο client.
    public static class FestivalCreateRequest {
        private String name;        // Όνομα φεστιβάλ
        private String description; // Περιγραφή φεστιβάλ
        private String venue;       // Τοποθεσία διεξαγωγής

        // Getters
        public String getName(){return name;}
        public String getDescription(){return description;}
        public String getVenue(){return venue;}

        // Setters
        public void setName(String n){this.name=n;}
        public void setDescription(String d){this.description=d;}
        public void setVenue(String v){this.venue=v;}
    }
}
