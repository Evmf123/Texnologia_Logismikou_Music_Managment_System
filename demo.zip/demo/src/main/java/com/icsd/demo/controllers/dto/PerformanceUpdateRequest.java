package com.icsd.demo.controllers.dto;

import java.util.List;

public class PerformanceUpdateRequest {
    private String name;
    private String description;
    private String genre;
    private Integer duration;
    private List<String> bandMembers;
    private List<String> technicalRequirements;
    private List<String> setlist;
    private List<String> merchandiseItems;

    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getGenre() { return genre; }
    public Integer getDuration() { return duration; }
    public List<String> getBandMembers() { return bandMembers; }
    public List<String> getTechnicalRequirements() { return technicalRequirements; }
    public List<String> getSetlist() { return setlist; }
    public List<String> getMerchandiseItems() { return merchandiseItems; }

    public void setName(String n){this.name=n;}
    public void setDescription(String d){this.description=d;}
    public void setGenre(String g){this.genre=g;}
    public void setDuration(Integer d){this.duration=d;}
    public void setBandMembers(List<String> b){this.bandMembers=b;}
    public void setTechnicalRequirements(List<String> t){this.technicalRequirements=t;}
    public void setSetlist(List<String> s){this.setlist=s;}
    public void setMerchandiseItems(List<String> m){this.merchandiseItems=m;}
}
