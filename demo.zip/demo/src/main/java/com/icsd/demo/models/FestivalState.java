package com.icsd.demo.models;

// Enum: FestivalState
public enum FestivalState {
    CREATED,
    SUBMISSION,
    ASSIGNMENT,
    REVIEW,
    SCHEDULING,
    FINAL_SUBMISSION,
    DECISION,
    ANNOUNCED
}
