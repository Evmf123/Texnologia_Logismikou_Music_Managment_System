package com.icsd.demo.models;

import jakarta.persistence.*;

// Σημαντικό: Αυτή η κλάση είναι οντότητα JPA και αντιστοιχεί σε πίνακα της βάσης δεδομένων
@Entity
// Ορίζει τον πίνακα και μοναδικούς περιορισμούς (unique constraints)
@Table(name="festival_user_role", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"festival_id","username","roleType"})
    // Σημείωση: Δεν μπορεί να υπάρξει δύο φορές η ίδια συνδυασμένη εγγραφή
    // για το ίδιο φεστιβάλ, τον ίδιο χρήστη και τον ίδιο τύπο ρόλου
})
public class FestivalUserRole {

    @Id // Ορίζει το πεδίο id ως primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    // Η τιμή του id θα δημιουργείται αυτόματα από τη βάση δεδομένων
    private Long id;

    private String username; // Το όνομα χρήστη που έχει έναν ρόλο σε ένα φεστιβάλ

    @ManyToOne(optional=false) 
    // Σχέση πολλών προς ένα: Πολλοί χρήστες/ρόλοι μπορούν να ανήκουν στο ίδιο φεστιβάλ
    // optional=false σημαίνει ότι το πεδίο δεν μπορεί να είναι null
    private Festival festival;

    @Enumerated(EnumType.STRING) 
    // Αποθηκεύει το enum RoleType ως String στη βάση (πχ "ADMIN", "PERFORMER")
    private RoleType roleType;

    // Default constructor απαραίτητος για JPA
    public FestivalUserRole() {}

    // Constructor για εύκολη δημιουργία αντικειμένων με όλα τα απαραίτητα πεδία
    public FestivalUserRole(String username, Festival festival, RoleType roleType) {
        this.username = username;
        this.festival = festival;
        this.roleType = roleType;
    }

    // Getters για όλα τα πεδία
    public Long getId() { return id; }
    public String getUsername() { return username; }
    public Festival getFestival() { return festival; }
    public RoleType getRoleType() { return roleType; }

    // Setters για όλα τα πεδία εκτός του id (που δημιουργείται αυτόματα)
    public void setUsername(String username) { this.username = username; }
    public void setFestival(Festival festival) { this.festival = festival; }
    public void setRoleType(RoleType roleType) { this.roleType = roleType; }
}
