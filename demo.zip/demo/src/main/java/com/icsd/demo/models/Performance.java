package com.icsd.demo.models;

import jakarta.persistence.*;
import java.sql.Timestamp;
import org.hibernate.annotations.CreationTimestamp;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Performance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // Πεδίο: id
    private Long id;

    @Column(nullable=false)
    // Πεδίο: name
    private String name;

    // Πεδίο: description
    private String description;
    // Πεδίο: genre
    private String genre;
    // Πεδίο: duration
    private Integer duration; // minutes

    @ElementCollection
    // Πεδίο: bandMembers
    private List<String> bandMembers = new ArrayList<>();

    @ElementCollection
    // Πεδίο: technicalRequirements
    private List<String> technicalRequirements = new ArrayList<>();

    @ElementCollection
    // Πεδίο: setlist
    private List<String> setlist = new ArrayList<>();

    @ElementCollection
    // Πεδίο: merchandiseItems
    private List<String> merchandiseItems = new ArrayList<>();

    @ManyToOne(optional=false)
    // Πεδίο: festival
    private Festival festival;

    @Column(nullable=false)
    // Πεδίο: mainArtistUsername
    private String mainArtistUsername; // store username of creator

    @CreationTimestamp
    // Πεδίο: createdAt
    private Timestamp createdAt;

    @Enumerated(EnumType.STRING)
    // Πεδίο: status
    private PerformanceStatus status = PerformanceStatus.CREATED;

    // Constructors, getters, setters
    public Performance() {}

    public Performance(String name, Festival festival, String mainArtistUsername) {
        this.name = name;
        this.festival = festival;
        this.mainArtistUsername = mainArtistUsername;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }
    public Integer getDuration() { return duration; }
    public void setDuration(Integer duration) { this.duration = duration; }
    public List<String> getBandMembers() { return bandMembers; }
    public List<String> getTechnicalRequirements() { return technicalRequirements; }
    public List<String> getSetlist() { return setlist; }
    public List<String> getMerchandiseItems() { return merchandiseItems; }
    public Festival getFestival() { return festival; }
    public void setFestival(Festival festival) { this.festival = festival; }
    public String getMainArtistUsername() { return mainArtistUsername; }
    public void setMainArtistUsername(String mainArtistUsername) { this.mainArtistUsername = mainArtistUsername; }
    public PerformanceStatus getStatus() { return status; }
    public void setStatus(PerformanceStatus status) { this.status = status; }
    public Timestamp getCreatedAt() { return createdAt; }
}
