
package com.icsd.demo.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import java.sql.Timestamp;
import org.hibernate.annotations.CreationTimestamp;

@Entity
public class User {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    int id;

    @Column(nullable=false)
    // Πεδίο: username
    private String username;
    
    @Column(nullable=false)
    // Πεδίο: password
    private String password;
    
    @Enumerated(EnumType.ORDINAL)
    // Πεδίο: gender
    private Gender gender;
    
    @CreationTimestamp
    // Πεδίο: create_at
    private Timestamp create_at;
}
