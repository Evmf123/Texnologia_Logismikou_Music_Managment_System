package com.icsd.demo.repositories;

import com.icsd.demo.models.FestivalUserRole; // Εισαγωγή της οντότητας FestivalUserRole
import com.icsd.demo.models.Festival;         // Εισαγωγή της οντότητας Festival
import com.icsd.demo.models.RoleType;         // Εισαγωγή του enum RoleType
import org.springframework.data.jpa.repository.JpaRepository; // Για βασικές CRUD λειτουργίες
import java.util.List;       // Για επιστροφή πολλαπλών εγγραφών
import java.util.Optional;   // Για επιστροφή πιθανώς κενής τιμής

// Δηλώνει repository για την οντότητα FestivalUserRole
// JpaRepository< FestivalUserRole, Long > σημαίνει ότι η οντότητα είναι FestivalUserRole και το primary key είναι Long
public interface FestivalUserRoleRepository extends JpaRepository<FestivalUserRole, Long> {

    // Μέθοδος που επιστρέφει όλες τις εγγραφές FestivalUserRole για ένα συγκεκριμένο φεστιβάλ
    List<FestivalUserRole> findByFestival(Festival festival);
    // Το Spring Data JPA δημιουργεί αυτόματα το query πίσω από τα παρασκήνια
    // Παράδειγμα χρήσης: βρίσκουμε όλους τους χρήστες και τους ρόλους τους για ένα φεστιβάλ

    // Μέθοδος που επιστρέφει όλες τις εγγραφές FestivalUserRole για ένα συγκεκριμένο username
    List<FestivalUserRole> findByUsername(String username);
    // Παράδειγμα χρήσης: βρίσκουμε όλα τα φεστιβάλ και ρόλους ενός χρήστη

    // Μέθοδος που επιστρέφει μία πιθανή εγγραφή FestivalUserRole για συνδυασμό φεστιβάλ, χρήστη και τύπου ρόλου
    Optional<FestivalUserRole> findByFestivalAndUsernameAndRoleType(Festival festival, String username, RoleType roleType);
    // Επιστρέφει Optional επειδή μπορεί να μην υπάρχει εγγραφή με αυτόν τον συνδυασμό
    // Παράδειγμα χρήσης: ελέγχουμε αν ένας χρήστης έχει ήδη συγκεκριμένο ρόλο σε ένα φεστιβάλ
}
