package com.icsd.demo.repositories;

import com.icsd.demo.models.Performance; // Εισαγωγή της οντότητας Performance
import com.icsd.demo.models.Festival;    // Εισαγωγή της οντότητας Festival
import org.springframework.data.jpa.repository.JpaRepository; // Για βασικές CRUD λειτουργίες
import java.util.List;       // Για επιστροφή πολλαπλών εγγραφών
import java.util.Optional;   // Για επιστροφή πιθανώς κενής τιμής

// Δηλώνει repository για την οντότητα Performance
// JpaRepository<Performance, Long> σημαίνει ότι η οντότητα είναι Performance και το primary key είναι Long
public interface PerformanceRepository extends JpaRepository<Performance, Long> {

    // Μέθοδος που επιστρέφει όλες τις performances ενός φεστιβάλ, ταξινομημένες πρώτα κατά genre και μετά κατά όνομα
    List<Performance> findByFestivalOrderByGenreAscNameAsc(Festival festival);
    // Το Spring Data JPA δημιουργεί αυτόματα το query πίσω από τα παρασκήνια
    // Παράδειγμα χρήσης: βρίσκουμε όλες τις performances για ένα φεστιβάλ και τις εμφανίζουμε ταξινομημένες

    // Μέθοδος που επιστρέφει μία πιθανή performance για ένα φεστιβάλ με συγκεκριμένο όνομα
    Optional<Performance> findByFestivalAndName(Festival festival, String name);
    // Επιστρέφει Optional επειδή μπορεί να μην υπάρχει performance με αυτό το όνομα στο φεστιβάλ
    // Παράδειγμα χρήσης: έλεγχος αν μια performance υπάρχει ήδη πριν τη δημιουργία νέας
}
