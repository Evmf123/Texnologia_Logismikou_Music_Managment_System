package com.icsd.demo.repositories;

import com.icsd.demo.models.Review; // Εισαγωγή της οντότητας Review
import org.springframework.data.jpa.repository.JpaRepository; // Για βασικές CRUD λειτουργίες

// Δηλώνει repository για την οντότητα Review
// JpaRepository<Review, Long> σημαίνει ότι η οντότητα είναι Review και το primary key είναι Long
// Χρησιμοποιώντας το JpaRepository, κληρονομούμε έτοιμες μεθόδους για:
// - Αποθήκευση (save)
// - Εύρεση (findById, findAll)
// - Διαγραφή (deleteById, delete)
// - Άλλες CRUD λειτουργίες
public interface ReviewRepository extends JpaRepository<Review, Long> {
    // μπορούμε να προσθέσουμε μεθόδους τύπου:
    // List<Review> findByPerformanceId(Long performanceId);
    // για να επιστρέφουμε όλες τις κριτικές μιας συγκεκριμένης performance
}
