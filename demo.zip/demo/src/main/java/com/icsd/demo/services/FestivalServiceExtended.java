package com.icsd.demo.services;

import com.icsd.demo.models.*;           // Εισαγωγή όλων των μοντέλων (Festival, RoleType, FestivalState κλπ.)
import com.icsd.demo.repositories.*;     // Εισαγωγή όλων των repositories
import org.springframework.stereotype.Service; // Σηματοδοτεί την κλάση ως Spring Service
import org.springframework.transaction.annotation.Transactional; // Για διαχείριση συναλλαγών

import java.util.List; // Εισαγωγή για πιθανή χρήση λιστών (δεν χρησιμοποιείται άμεσα εδώ)

// Δηλώνει ότι η κλάση είναι Spring Service
@Service
public class FestivalServiceExtended {

    // Repositories για διαχείριση Festival και ρόλων χρηστών σε φεστιβάλ
    private final FestivalRepository festivalRepository;
    private final FestivalUserRoleRepository roleRepository;

    // Constructor για dependency injection
    public FestivalServiceExtended(FestivalRepository festivalRepository,
                                   FestivalUserRoleRepository roleRepository) {
        this.festivalRepository = festivalRepository;
        this.roleRepository = roleRepository;
    }

    /**
     * Μεταβαίνει το φεστιβάλ στην κατάσταση SUBMISSION.
     * @param festivalId Το ID του φεστιβάλ
     * @param username Ο χρήστης που κάνει την ενέργεια
     * @return Το ενημερωμένο αντικείμενο Festival
     */
    @Transactional
    public Festival startSubmission(Long festivalId, String username) {
        // Βρίσκει το φεστιβάλ ή ρίχνει λάθος αν δεν υπάρχει
        Festival f = festivalRepository.findById(festivalId).orElseThrow(() -> new IllegalArgumentException("Festival not found"));

        // Έλεγχος αν ο χρήστης είναι οργανωτής
        checkOrganizer(f, username);

        // Έλεγχος κατάστασης: πρέπει να είναι CREATED
        if (f.getState() != FestivalState.CREATED) throw new IllegalStateException("Festival must be in CREATED state");

        // Αλλαγή κατάστασης σε SUBMISSION
        f.setState(FestivalState.SUBMISSION);

        // Αποθήκευση αλλαγής στη βάση
        return festivalRepository.save(f);
    }

    /**
     * Μεταβαίνει το φεστιβάλ στην κατάσταση ASSIGNMENT.
     * Η λογική επαναλαμβάνεται για όλες τις μεταβάσεις.
     */
    @Transactional
    public Festival startAssignment(Long festivalId, String username) {
        Festival f = festivalRepository.findById(festivalId).orElseThrow(() -> new IllegalArgumentException("Festival not found"));
        checkOrganizer(f, username);
        if (f.getState() != FestivalState.SUBMISSION) throw new IllegalStateException("Festival must be in SUBMISSION state");
        f.setState(FestivalState.ASSIGNMENT);
        return festivalRepository.save(f);
    }

    @Transactional
    public Festival startReview(Long festivalId, String username) {
        Festival f = festivalRepository.findById(festivalId).orElseThrow(() -> new IllegalArgumentException("Festival not found"));
        checkOrganizer(f, username);
        if (f.getState() != FestivalState.ASSIGNMENT) throw new IllegalStateException("Festival must be in ASSIGNMENT state");
        f.setState(FestivalState.REVIEW);
        return festivalRepository.save(f);
    }

    @Transactional
    public Festival startScheduling(Long festivalId, String username) {
        Festival f = festivalRepository.findById(festivalId).orElseThrow(() -> new IllegalArgumentException("Festival not found"));
        checkOrganizer(f, username);
        if (f.getState() != FestivalState.REVIEW) throw new IllegalStateException("Festival must be in REVIEW state");
        f.setState(FestivalState.SCHEDULING);
        return festivalRepository.save(f);
    }

    @Transactional
    public Festival startFinalSubmission(Long festivalId, String username) {
        Festival f = festivalRepository.findById(festivalId).orElseThrow(() -> new IllegalArgumentException("Festival not found"));
        checkOrganizer(f, username);
        if (f.getState() != FestivalState.SCHEDULING) throw new IllegalStateException("Festival must be in SCHEDULING state");
        f.setState(FestivalState.FINAL_SUBMISSION);
        return festivalRepository.save(f);
    }

    @Transactional
    public Festival startDecision(Long festivalId, String username) {
        Festival f = festivalRepository.findById(festivalId).orElseThrow(() -> new IllegalArgumentException("Festival not found"));
        checkOrganizer(f, username);
        if (f.getState() != FestivalState.FINAL_SUBMISSION) throw new IllegalStateException("Festival must be in FINAL_SUBMISSION state");

        // Σημείωση: Εδώ μπορεί να γίνει αυτόματος έλεγχος και απόρριψη κάποιων performances
        // Η συγκεκριμένη λογική μπορεί να εφαρμοστεί στο PerformanceService κατά τη λήψη αποφάσεων

        f.setState(FestivalState.DECISION);
        return festivalRepository.save(f);
    }

    @Transactional
    public Festival announceFestival(Long festivalId, String username) {
        Festival f = festivalRepository.findById(festivalId).orElseThrow(() -> new IllegalArgumentException("Festival not found"));
        checkOrganizer(f, username);
        if (f.getState() != FestivalState.DECISION) throw new IllegalStateException("Festival must be in DECISION state");

        // Τελική ανακοίνωση φεστιβάλ
        f.setState(FestivalState.ANNOUNCED);
        return festivalRepository.save(f);
    }

    /**
     * Βοηθητική μέθοδος για έλεγχο αν ο χρήστης είναι οργανωτής.
     * @param f Το φεστιβάλ
     * @param username Το username του χρήστη
     */
    private void checkOrganizer(Festival f, String username) {
        if (username == null) throw new SecurityException("No user header");

        // Ελέγχει αν υπάρχει εγγραφή με συγκεκριμένο ρόλο ORGANIZER
        boolean isOrganizer = roleRepository.findByFestivalAndUsernameAndRoleType(f, username, RoleType.ORGANIZER).isPresent();
        if (!isOrganizer) throw new SecurityException("Only organizers can perform this action");
    }
}
