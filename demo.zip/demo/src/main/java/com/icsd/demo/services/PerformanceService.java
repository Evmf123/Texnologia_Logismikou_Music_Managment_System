package com.icsd.demo.services;

import com.icsd.demo.models.*;            // Εισαγωγή όλων των μοντέλων (Performance, Festival, RoleType κλπ.)
import com.icsd.demo.repositories.*;      // Εισαγωγή όλων των repositories
import org.springframework.stereotype.Service; // Σηματοδοτεί την κλάση ως Spring Service
import org.springframework.transaction.annotation.Transactional; // Υποστηρίζει διαχείριση συναλλαγών
import java.util.Optional;               // Για πιθανώς κενές επιστροφές
import java.util.List;                   // Για λίστες χρηστών, μελών κλπ.

// Δηλώνει ότι η κλάση είναι Spring Service
@Service
public class PerformanceService {

    // Repositories για διαχείριση Performance, Festival και ρόλων χρηστών
    private final PerformanceRepository performanceRepository;
    private final FestivalRepository festivalRepository;
    private final FestivalUserRoleRepository roleRepository;

    // Constructor για dependency injection των repositories
    public PerformanceService(PerformanceRepository performanceRepository,
                              FestivalRepository festivalRepository,
                              FestivalUserRoleRepository roleRepository) {
        this.performanceRepository = performanceRepository;
        this.festivalRepository = festivalRepository;
        this.roleRepository = roleRepository;
    }

    /**
     * Δημιουργεί μία νέα performance σε συγκεκριμένο φεστιβάλ.
     * @param festivalId Το ID του φεστιβάλ
     * @param name Το όνομα της performance
     * @param creatorUsername Ο χρήστης που δημιουργεί την performance
     * @return Το αντικείμενο Performance που δημιουργήθηκε
     */
    @Transactional
    public Performance createPerformance(Long festivalId, String name, String creatorUsername) {
        // Βρίσκει το φεστιβάλ ή ρίχνει λάθος αν δεν υπάρχει
        Festival festival = festivalRepository.findById(festivalId)
            .orElseThrow(() -> new IllegalArgumentException("Festival not found"));

        // Έλεγχος μοναδικότητας ονόματος μέσα στο φεστιβάλ
        if (performanceRepository.findByFestivalAndName(festival, name).isPresent()) {
            throw new IllegalArgumentException("Performance name must be unique within festival");
        }

        // Δημιουργία νέας performance
        Performance p = new Performance(name, festival, creatorUsername);

        // Προσθήκη του δημιουργού ως μέλος της μπάντας
        p.getBandMembers().add(creatorUsername);

        // Αποθήκευση performance στη βάση
        p = performanceRepository.save(p);

        // Διασφάλιση ότι ο χρήστης έχει ρόλο ARTIST για το φεστιβάλ
        roleRepository.findByFestivalAndUsernameAndRoleType(festival, creatorUsername, RoleType.ARTIST)
            .orElseGet(() -> roleRepository.save(new FestivalUserRole(creatorUsername, festival, RoleType.ARTIST)));

        return p;
    }

    /**
     * Βρίσκει μία performance με βάση το ID της
     * @param id Το ID της performance
     * @return Optional<Performance> που μπορεί να είναι κενό αν δεν υπάρχει
     */
    public Optional<Performance> findById(Long id) {
        return performanceRepository.findById(id);
    }

    /**
     * Υποβάλλει μία performance για αξιολόγηση.
     * Έλεγχοι:
     * - Μόνο ο κύριος καλλιτέχνης ή τα μέλη της μπάντας μπορούν να υποβάλουν
     * - Το φεστιβάλ πρέπει να είναι στην κατάσταση SUBMISSION
     * - Όλα τα απαραίτητα πεδία πρέπει να είναι συμπληρωμένα
     *
     * @param performanceId Το ID της performance
     * @param username Ο χρήστης που κάνει την υποβολή
     */
    @Transactional
    public void submitPerformance(Long performanceId, String username) {
        // Βρίσκει την performance ή ρίχνει λάθος αν δεν υπάρχει
        Performance p = performanceRepository.findById(performanceId)
            .orElseThrow(() -> new IllegalArgumentException("Performance not found"));

        // Έλεγχος αν ο χρήστης είναι κύριος καλλιτέχνης ή μέλος της μπάντας
        if (!p.getMainArtistUsername().equals(username) && !p.getBandMembers().contains(username)) {
            throw new SecurityException("Only artists of the performance can submit");
        }

        // Έλεγχος κατάστασης φεστιβάλ: πρέπει να είναι SUBMISSION
        if (p.getFestival().getState() != FestivalState.SUBMISSION) {
            throw new IllegalStateException("Festival not in SUBMISSION state");
        }

        // Βασικός έλεγχος πληρότητας της performance
        if (p.getName() == null || p.getDescription() == null || p.getGenre() == null || p.getDuration() == null
            || p.getBandMembers().isEmpty() || p.getTechnicalRequirements().isEmpty() || p.getSetlist().isEmpty()
            || p.getMerchandiseItems().isEmpty()) {
            throw new IllegalArgumentException("Performance details are incomplete");
        }

        // Ορισμός κατάστασης performance ως SUBMITTED
        p.setStatus(PerformanceStatus.SUBMITTED);

        // Αποθήκευση αλλαγής στη βάση
        performanceRepository.save(p);
    }
}
