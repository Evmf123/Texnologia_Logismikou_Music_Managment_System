package com.icsd.demo.controllers;

import com.icsd.demo.models.Performance;
import com.icsd.demo.models.Review;
import com.icsd.demo.services.PerformanceServiceExtended;
import com.icsd.demo.controllers.dto.PerformanceUpdateRequest;
import com.icsd.demo.controllers.dto.ReviewRequest;
import org.springframework.web.bind.annotation.*;

// Controller για διαχειριστικές ενέργειες πάνω σε Performances (συμμετοχές συγκροτημάτων).
// Εδώ έχουμε endpoints για ενημέρωση, απόσυρση, αξιολόγηση, αποδοχή κ.λπ.
@RestController
@RequestMapping("/api/admin/performances")
public class PerformanceAdminController {

    // Service που περιέχει την επιχειρησιακή λογική για τα performances
    private final PerformanceServiceExtended service;

    // Constructor injection: η Spring παρέχει το service
    public PerformanceAdminController(PerformanceServiceExtended service) {
        this.service = service;
    }

    //  ENDPOINTS 

    // Ενημέρωση στοιχείων μιας συμμετοχής (performance).
    // Ο χρήστης στέλνει JSON με τα πεδία που θέλει να αλλάξει.
    @PutMapping("/{id}")
    public Performance updatePerformance(@RequestHeader("X-User") String username, @PathVariable Long id, @RequestBody PerformanceUpdateRequest req) {
        Performance tmp = new Performance();
        tmp.setName(req.getName());
        tmp.setDescription(req.getDescription());
        tmp.setGenre(req.getGenre());
        tmp.setDuration(req.getDuration());
        // Αν υπάρχουν λίστες (μέλη, απαιτήσεις, setlist, merchandise), προστίθενται.
        if (req.getBandMembers()!=null) tmp.getBandMembers().addAll(req.getBandMembers());
        if (req.getTechnicalRequirements()!=null) tmp.getTechnicalRequirements().addAll(req.getTechnicalRequirements());
        if (req.getSetlist()!=null) tmp.getSetlist().addAll(req.getSetlist());
        if (req.getMerchandiseItems()!=null) tmp.getMerchandiseItems().addAll(req.getMerchandiseItems());
        // Κλήση του service για να γίνει η ενημέρωση
        return service.updatePerformance(id, username, tmp);
    }

    // Προσθήκη νέου μέλους στο συγκρότημα ενός performance
    @PostMapping("/{id}/addBandMember")
    public Performance addBandMember(@RequestHeader("X-User") String username, @PathVariable Long id, @RequestParam String newMember) {
        return service.addBandMember(id, username, newMember);
    }

    // Απόσυρση μιας συμμετοχής (π.χ. αν το συγκρότημα αποσύρει την αίτηση)
    @DeleteMapping("/{id}")
    public void withdraw(@RequestHeader("X-User") String username, @PathVariable Long id) {
        service.withdrawPerformance(id, username);
    }

    // Ανάθεση staff (π.χ. κριτή ή υπεύθυνου) σε μια συμμετοχή
    @PostMapping("/{id}/assignStaff")
    public void assignStaff(@RequestHeader("X-User") String username, @PathVariable Long id, @RequestParam String staff) {
        service.assignStaff(id, username, staff);
    }

    // Υποβολή αξιολόγησης (review) για ένα performance
    @PostMapping("/{id}/review")
    public Review review(@RequestHeader("X-User") String username, @PathVariable Long id, @RequestBody ReviewRequest req) {
        return service.reviewPerformance(id, username, req.getScore(), req.getComments());
    }

    // Έγκριση μιας συμμετοχής μετά την αξιολόγηση
    @PostMapping("/{id}/approve")
    public void approve(@RequestHeader("X-User") String username, @PathVariable Long id) {
        service.approvePerformance(id, username);
    }

    // Απόρριψη μιας συμμετοχής, με αιτιολογία
    @PostMapping("/{id}/reject")
    public void reject(@RequestHeader("X-User") String username, @PathVariable Long id, @RequestParam String reason) {
        service.rejectPerformance(id, username, reason);
    }

    // Τελική υποβολή μιας συμμετοχής (με ενημερωμένα στοιχεία όπως setlist).
    @PostMapping("/{id}/finalSubmit")
    public void finalSubmit(@RequestHeader("X-User") String username, @PathVariable Long id, @RequestBody PerformanceUpdateRequest req) {
        Performance tmp = new Performance();
        tmp.setName(req.getName());
        tmp.setDescription(req.getDescription());
        tmp.setGenre(req.getGenre());
        tmp.setDuration(req.getDuration());
        if (req.getSetlist()!=null) tmp.getSetlist().addAll(req.getSetlist());
        service.finalSubmit(id, username, tmp);
    }

    // Αποδοχή της συμμετοχής για το τελικό πρόγραμμα του φεστιβάλ
    @PostMapping("/{id}/accept")
    public void accept(@RequestHeader("X-User") String username, @PathVariable Long id) {
        service.acceptPerformance(id, username);
    }
}
