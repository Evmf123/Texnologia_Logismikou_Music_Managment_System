package com.icsd.demo.controllers;

import com.icsd.demo.models.*;
import com.icsd.demo.services.PerformanceService;
import org.springframework.web.bind.annotation.*;

/**
 * Controller for performance creation and submission.
 * Auth via X-User header.
 * 
 * Σημαντικό: Όλοι οι χειρισμοί performances γίνονται μέσω αιτημάτων HTTP
 * και η αυθεντικοποίηση βασίζεται στην επικεφαλίδα "X-User".
 */
@RestController // Δηλώνει ότι αυτή η κλάση είναι REST controller, δηλαδή χειρίζεται HTTP αιτήματα και επιστρέφει δεδομένα JSON.
@RequestMapping("/api/performances") // Βασικό URL path για όλα τα endpoints της κλάσης
public class PerformanceController {

    private final PerformanceService performanceService; 
    // Δημιουργούμε ένα service αντικείμενο για τη διαχείριση της λογικής που αφορά performances.
    // Το Spring θα το περάσει μέσω dependency injection στον constructor.

    // Constructor για το PerformanceController
    public PerformanceController(PerformanceService performanceService) {
        this.performanceService = performanceService;
    }

    /**
     * Endpoint για δημιουργία νέας performance.
     * Παίρνει το όνομα χρήστη από το header "X-User" και το σώμα του request
     * ως PerformanceCreateRequest.
     * 
     * @param username Το όνομα του χρήστη που κάνει το αίτημα
     * @param req Το σώμα του αιτήματος που περιέχει festivalId και name
     * @return Επιστρέφει το αντικείμενο Performance που μόλις δημιουργήθηκε
     */
    @PostMapping
    public Performance createPerformance(@RequestHeader("X-User") String username,
                                         @RequestBody PerformanceCreateRequest req) {
        // Καλεί το service για να δημιουργήσει μια νέα performance και επιστρέφει το αποτέλεσμα
        return performanceService.createPerformance(req.getFestivalId(), req.getName(), username);
    }

    /**
     * Endpoint για υποβολή (submit) μιας performance.
     * Παίρνει το όνομα χρήστη από το header "X-User" και το id της performance από το path.
     * 
     * @param username Το όνομα του χρήστη που κάνει το αίτημα
     * @param id Το ID της performance που θέλουμε να υποβάλουμε
     */
    @PostMapping("/{id}/submit")
    public void submitPerformance(@RequestHeader("X-User") String username,
                                  @PathVariable Long id) {
        // Καλεί το service για να υποβάλει την performance
        performanceService.submitPerformance(id, username);
    }

    /**
     * Εσωτερική κλάση για να αντιπροσωπεύει το σώμα του αιτήματος
     * κατά τη δημιουργία μιας νέας performance.
     * Περιλαμβάνει μόνο τα απαραίτητα πεδία: festivalId και name.
     */
    public static class PerformanceCreateRequest {
        private Long festivalId; // Το ID του φεστιβάλ όπου ανήκει η performance
        private String name;     // Το όνομα της performance

        // Getter για το festivalId
        public Long getFestivalId(){return festivalId;}
        // Getter για το name
        public String getName(){return name;}
        // Setter για το festivalId
        public void setFestivalId(Long id){this.festivalId=id;}
        // Setter για το name
        public void setName(String name){this.name=name;}
    }
}
