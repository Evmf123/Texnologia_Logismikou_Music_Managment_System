package com.icsd.demo.controllers;

//import com.icsd.demo.models.User; 
// Σχόλιο: Αυτή η γραμμή είναι σχολιασμένη. Υποδηλώνει ότι ίσως στο μέλλον θα χρησιμοποιηθεί η κλάση User για κάποιο endpoint.

// Εισαγωγή απαραίτητων κλάσεων από Spring
import org.springframework.http.ResponseEntity; // Για τη δημιουργία HTTP απαντήσεων με status code και body
import org.springframework.web.bind.annotation.GetMapping; // Αντιστοιχεί σε HTTP GET αιτήματα
import org.springframework.web.bind.annotation.RequestMapping; // Δηλώνει το base path για όλα τα endpoints της κλάσης
import org.springframework.web.bind.annotation.RestController; // Δηλώνει ότι η κλάση είναι REST controller

// Δηλώνει ότι αυτή η κλάση είναι REST controller
@RestController
// Όλα τα endpoints σε αυτή την κλάση θα έχουν base path "/users"
@RequestMapping("/users")
public class UserController {
    
    // Σχόλιο: Παράδειγμα URL για το endpoint
    // http://localhost:8080/users
    @GetMapping // Δηλώνει ότι αυτή η μέθοδος αντιστοιχεί σε HTTP GET στο path "/users"
    public ResponseEntity<String> hello(){
        // Επιστρέφει HTTP 200 OK με σώμα "Hello there"
        // ResponseEntity είναι χρήσιμο όταν θέλουμε να ελέγχουμε status code, headers ή body
        return ResponseEntity.ok().body("Hello there");
    }
}
