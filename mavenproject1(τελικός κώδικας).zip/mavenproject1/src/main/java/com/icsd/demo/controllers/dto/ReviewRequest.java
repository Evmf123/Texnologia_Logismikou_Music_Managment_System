package com.icsd.demo.controllers.dto;

public class ReviewRequest {
    private int score;
    private String comments;
    public int getScore(){return score;}
    public String getComments(){return comments;}
    public void setScore(int s){this.score=s;}
    public void setComments(String c){this.comments=c;}
}
