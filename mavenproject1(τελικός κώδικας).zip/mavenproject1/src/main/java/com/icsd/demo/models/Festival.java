package com.icsd.demo.models;

import jakarta.persistence.*;
import java.sql.Timestamp;
import org.hibernate.annotations.CreationTimestamp;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Festival {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // Πεδίο: id
    private Long id;

    @Column(nullable=false, unique=true)
    // Πεδίο: name
    private String name;

    // Πεδίο: description
    private String description;

    // Πεδίο: venue
    private String venue;

    // Πεδίο: startDate
    private Timestamp startDate;
    // Πεδίο: endDate
    private Timestamp endDate;

    @Enumerated(EnumType.STRING)
    // Πεδίο: state
    private FestivalState state = FestivalState.CREATED;

    @CreationTimestamp
    // Πεδίο: createdAt
    private Timestamp createdAt;

    // Constructors, getters, setters
    public Festival() {}

    public Festival(String name, String description, String venue) {
        this.name = name;
        this.description = description;
        this.venue = venue;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getVenue() { return venue; }
    public void setVenue(String venue) { this.venue = venue; }
    public FestivalState getState() { return state; }
    public void setState(FestivalState state) { this.state = state; }
    public Timestamp getCreatedAt() { return createdAt; }
    public Timestamp getStartDate() { return startDate; }
    public void setStartDate(Timestamp startDate) { this.startDate = startDate; }
    public Timestamp getEndDate() { return endDate; }
    public void setEndDate(Timestamp endDate) { this.endDate = endDate; }
}
