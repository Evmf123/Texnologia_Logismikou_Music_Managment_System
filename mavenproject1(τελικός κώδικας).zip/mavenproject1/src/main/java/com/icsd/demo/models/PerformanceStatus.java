package com.icsd.demo.models;

// Enum: PerformanceStatus
public enum PerformanceStatus {
    CREATED,
    SUBMITTED,
    APPROVED,
    REJECTED,
    FINAL_SUBMITTED,
    ACCEPTED
}
