package com.icsd.demo.models;

import jakarta.persistence.*;
import java.sql.Timestamp;
import org.hibernate.annotations.CreationTimestamp;

@Entity
public class Review {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // Πεδίο: id
    private Long id;

    // Πεδίο: reviewerUsername
    private String reviewerUsername; // STAFF username

    // Πεδίο: score
    private int score;

    @Column(length=2000)
    // Πεδίο: comments
    private String comments;

    @ManyToOne(optional=false)
    // Πεδίο: performance
    private Performance performance;

    @CreationTimestamp
    // Πεδίο: createdAt
    private Timestamp createdAt;

    public Review() {}

    public Review(String reviewerUsername, int score, String comments, Performance performance) {
        this.reviewerUsername = reviewerUsername;
        this.score = score;
        this.comments = comments;
        this.performance = performance;
    }

    public Long getId() { return id; }
    public String getReviewerUsername() { return reviewerUsername; }
    public int getScore() { return score; }
    public String getComments() { return comments; }
    public Performance getPerformance() { return performance; }
    public Timestamp getCreatedAt() { return createdAt; }
}
