package com.icsd.demo.models;

// Enum: RoleType
public enum RoleType {
    VISITOR, ARTIST, STAFF, ORGANIZER
}
