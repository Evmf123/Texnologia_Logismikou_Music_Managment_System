package com.icsd.demo.repositories;

import com.icsd.demo.models.Festival; // Εισαγωγή της οντότητας Festival
import org.springframework.data.jpa.repository.JpaRepository; // Βασικό interface του Spring Data JPA
import java.util.Optional; // Για τύπους που μπορεί να μην επιστρέφουν τιμή

// Δηλώνει ένα repository για την οντότητα Festival
// Το JpaRepository παρέχει όλες τις βασικές CRUD λειτουργίες (create, read, update, delete)
// <Festival, Long> σημαίνει ότι το repository δουλεύει με οντότητες Festival και το primary key είναι τύπου Long
public interface FestivalRepository extends JpaRepository<Festival, Long> {

    // Μέθοδος που ψάχνει ένα Festival με βάση το όνομά του
    // Επιστρέφει Optional<Festival> γιατί μπορεί να μην υπάρχει εγγραφή με το συγκεκριμένο όνομα
    Optional<Festival> findByName(String name);
    
    // Σημείωση: Το Spring Data JPA αναγνωρίζει αυτόματα το findByName και δημιουργεί το query πίσω από τα παρασκήνια
}
