package com.icsd.demo.services;

import com.icsd.demo.models.*;             // Εισαγωγή όλων των μοντέλων (Festival, FestivalUserRole, RoleType κλπ.)
import com.icsd.demo.repositories.*;       // Εισαγωγή όλων των repositories
import org.springframework.stereotype.Service; // Σηματοδοτεί την κλάση ως Spring Service
import org.springframework.transaction.annotation.Transactional; // Υποστηρίζει διαχείριση συναλλαγών
import java.util.Optional;                 // Για πιθανώς κενές επιστροφές

// Δηλώνει ότι η κλάση είναι Spring Service
@Service
public class FestivalService {

    // Repositories για διαχείριση Festival και FestivalUserRole
    private final FestivalRepository festivalRepository;
    private final FestivalUserRoleRepository roleRepository;

    // Constructor για dependency injection των repositories
    public FestivalService(FestivalRepository festivalRepository,
                           FestivalUserRoleRepository roleRepository) {
        this.festivalRepository = festivalRepository;
        this.roleRepository = roleRepository;
    }

    /**
     * Δημιουργεί ένα νέο Festival και προσθέτει τον δημιουργό ως ORGANIZER.
     * Η μέθοδος είναι transactional, δηλαδή αν κάτι πάει στραβά
     * η όλη διαδικασία θα αναιρεθεί.
     *
     * @param name Όνομα του φεστιβάλ
     * @param description Περιγραφή του φεστιβάλ
     * @param venue Χώρος διεξαγωγής
     * @param creatorUsername Όνομα χρήστη δημιουργού
     * @return Το αντικείμενο Festival που δημιουργήθηκε
     */
    @Transactional
    public Festival createFestival(String name, String description, String venue, String creatorUsername) {
        // Έλεγχος μοναδικότητας ονόματος φεστιβάλ
        if (festivalRepository.findByName(name).isPresent()) {
            throw new IllegalArgumentException("Festival name must be unique");
        }

        // Δημιουργία νέου αντικειμένου Festival
        Festival f = new Festival(name, description, venue);

        // Αποθήκευση στη βάση δεδομένων
        f = festivalRepository.save(f);

        // Δημιουργία ρόλου ORGANIZER για τον δημιουργό
        FestivalUserRole r = new FestivalUserRole(creatorUsername, f, RoleType.ORGANIZER);

        // Αποθήκευση ρόλου στη βάση δεδομένων
        roleRepository.save(r);

        // Επιστροφή του φεστιβάλ που δημιουργήθηκε
        return f;
    }

    /**
     * Βρίσκει ένα Festival με βάση το ID του.
     * @param id Το ID του φεστιβάλ
     * @return Optional<Festival> που μπορεί να είναι κενό αν δεν υπάρχει το φεστιβάλ
     */
    public Optional<Festival> findById(Long id) {
        return festivalRepository.findById(id);
    }
}
