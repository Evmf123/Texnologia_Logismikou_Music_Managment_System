package com.icsd.demo.services;

import com.icsd.demo.models.*;           // Εισαγωγή όλων των μοντέλων (Performance, Festival, Review, RoleType κλπ.)
import com.icsd.demo.repositories.*;     // Εισαγωγή όλων των repositories
import org.springframework.stereotype.Service; // Σηματοδοτεί την κλάση ως Spring Service
import org.springframework.transaction.annotation.Transactional; // Υποστηρίζει διαχείριση συναλλαγών

import java.util.List;                   // Για λίστες χρηστών, μελών κλπ.

// Δηλώνει ότι η κλάση είναι Spring Service
@Service
public class PerformanceServiceExtended {

    // Repositories για διαχείριση performances, festivals, roles και reviews
    private final PerformanceRepository performanceRepository;
    private final FestivalRepository festivalRepository;
    private final FestivalUserRoleRepository roleRepository;
    private final ReviewRepository reviewRepository;

    // Constructor για dependency injection
    public PerformanceServiceExtended(PerformanceRepository performanceRepository,
                                      FestivalRepository festivalRepository,
                                      FestivalUserRoleRepository roleRepository,
                                      ReviewRepository reviewRepository) {
        this.performanceRepository = performanceRepository;
        this.festivalRepository = festivalRepository;
        this.roleRepository = roleRepository;
        this.reviewRepository = reviewRepository;
    }

    /**
     * Ενημέρωση στοιχείων μιας performance.
     * Μόνο οι καλλιτέχνες μπορούν να ενημερώσουν και μόνο αν η κατάσταση είναι CREATED.
     * Εφαρμόζει μόνο μη-κενές τιμές από το αντικείμενο 'updated'.
     */
    @Transactional
    public Performance updatePerformance(Long performanceId, String username, Performance updated) {
        Performance p = performanceRepository.findById(performanceId)
                .orElseThrow(() -> new IllegalArgumentException("Performance not found"));

        // Έλεγχος αν ο χρήστης είναι καλλιτέχνης
        if (!p.getMainArtistUsername().equals(username) && (p.getBandMembers()==null || !p.getBandMembers().contains(username))) {
            throw new SecurityException("Only artists can update their performance");
        }

        // Έλεγχος κατάστασης: μόνο CREATED επιτρέπεται
        if (p.getStatus() != PerformanceStatus.CREATED) throw new IllegalStateException("Only CREATED performances can be updated");

        // Ενημέρωση πεδίων (μόνο μη-κενά)
        if (updated.getName() != null) p.setName(updated.getName());
        if (updated.getDescription() != null) p.setDescription(updated.getDescription());
        if (updated.getGenre() != null) p.setGenre(updated.getGenre());
        if (updated.getDuration() != null) p.setDuration(updated.getDuration());

        if (updated.getBandMembers() != null && !updated.getBandMembers().isEmpty()) {
            p.getBandMembers().clear(); 
            p.getBandMembers().addAll(updated.getBandMembers());
        }
        if (updated.getTechnicalRequirements() != null && !updated.getTechnicalRequirements().isEmpty()) {
            p.getTechnicalRequirements().clear();
            p.getTechnicalRequirements().addAll(updated.getTechnicalRequirements());
        }
        if (updated.getSetlist() != null && !updated.getSetlist().isEmpty()) {
            p.getSetlist().clear();
            p.getSetlist().addAll(updated.getSetlist());
        }
        if (updated.getMerchandiseItems() != null && !updated.getMerchandiseItems().isEmpty()) {
            p.getMerchandiseItems().clear();
            p.getMerchandiseItems().addAll(updated.getMerchandiseItems());
        }

        return performanceRepository.save(p);
    }

    /**
     * Προσθήκη νέου μέλους μπάντας σε performance.
     * Μόνο ο κύριος καλλιτέχνης μπορεί να προσθέσει μέλη.
     * Ο χρήστης που προστίθεται λαμβάνει ρόλο ARTIST στο φεστιβάλ.
     */
    @Transactional
    public Performance addBandMember(Long performanceId, String username, String newMember) {
        Performance p = performanceRepository.findById(performanceId)
                .orElseThrow(() -> new IllegalArgumentException("Performance not found"));

        if (!p.getMainArtistUsername().equals(username)) throw new SecurityException("Only main artist can add band members");

        if (!p.getBandMembers().contains(newMember)) p.getBandMembers().add(newMember);

        // Διασφάλιση ότι ο νέος χρήστης έχει ρόλο ARTIST
        roleRepository.findByFestivalAndUsernameAndRoleType(p.getFestival(), newMember, RoleType.ARTIST)
            .orElseGet(() -> roleRepository.save(new FestivalUserRole(newMember, p.getFestival(), RoleType.ARTIST)));

        return performanceRepository.save(p);
    }

    /**
     * Απόσυρση μιας performance.
     * Μόνο οι καλλιτέχνες μπορούν να αποσύρουν.
     * Δεν επιτρέπεται η απόσυρση αν η performance έχει υποβληθεί.
     */
    @Transactional
    public void withdrawPerformance(Long performanceId, String username) {
        Performance p = performanceRepository.findById(performanceId)
                .orElseThrow(() -> new IllegalArgumentException("Performance not found"));

        if (!p.getMainArtistUsername().equals(username) && (p.getBandMembers()==null || !p.getBandMembers().contains(username))) {
            throw new SecurityException("Only artists can withdraw");
        }

        if (p.getStatus() == PerformanceStatus.SUBMITTED) throw new IllegalStateException("Cannot withdraw after submission");

        performanceRepository.delete(p);
    }

    /**
     * Ανάθεση staff σε performance.
     * Μόνο οργανωτές μπορούν να αναθέτουν και το φεστιβάλ πρέπει να είναι σε ASSIGNMENT.
     * Ο χρήστης που ανατίθεται πρέπει να έχει ρόλο STAFF.
     */
    @Transactional
    public void assignStaff(Long performanceId, String organizerUsername, String staffUsername) {
        Performance p = performanceRepository.findById(performanceId)
                .orElseThrow(() -> new IllegalArgumentException("Performance not found"));
        Festival f = p.getFestival();

        if (!roleRepository.findByFestivalAndUsernameAndRoleType(f, organizerUsername, RoleType.ORGANIZER).isPresent())
            throw new SecurityException("Only organizers can assign staff");
        if (f.getState() != FestivalState.ASSIGNMENT) throw new IllegalStateException("Festival not in ASSIGNMENT state");
        if (!roleRepository.findByFestivalAndUsernameAndRoleType(f, staffUsername, RoleType.STAFF).isPresent())
            throw new IllegalArgumentException("User is not registered as STAFF for festival");

        if (!p.getBandMembers().contains(staffUsername)) p.getBandMembers().add(staffUsername);
        performanceRepository.save(p);
    }

    /**
     * Υποβολή review για performance από staff.
     * Το φεστιβάλ πρέπει να είναι σε REVIEW state.
     * Ο staff πρέπει να έχει ανατεθεί στη συγκεκριμένη performance.
     */
    @Transactional
    public Review reviewPerformance(Long performanceId, String staffUsername, int score, String comments) {
        Performance p = performanceRepository.findById(performanceId)
                .orElseThrow(() -> new IllegalArgumentException("Performance not found"));
        Festival f = p.getFestival();

        if (f.getState() != FestivalState.REVIEW) throw new IllegalStateException("Festival not in REVIEW state");
        if (!p.getBandMembers().contains(staffUsername)) throw new SecurityException("Staff not assigned to performance");

        Review r = new Review(staffUsername, score, comments, p);
        r = reviewRepository.save(r);
        return r;
    }

    /**
     * Έγκριση performance από οργανωτή.
     * Το φεστιβάλ πρέπει να είναι σε SCHEDULING state.
     */
    @Transactional
    public void approvePerformance(Long performanceId, String organizerUsername) {
        Performance p = performanceRepository.findById(performanceId)
                .orElseThrow(() -> new IllegalArgumentException("Performance not found"));
        Festival f = p.getFestival();

        if (!roleRepository.findByFestivalAndUsernameAndRoleType(f, organizerUsername, RoleType.ORGANIZER).isPresent())
            throw new SecurityException("Only organizers can approve");
        if (f.getState() != FestivalState.SCHEDULING) throw new IllegalStateException("Festival not in SCHEDULING state");

        p.setStatus(PerformanceStatus.APPROVED);
        performanceRepository.save(p);
    }

    /**
     * Απόρριψη performance από οργανωτή.
     * Επιτρέπεται μόνο σε SCHEDULING ή DECISION state.
     * Ο λόγος απόρριψης εμφανίζεται στην κονσόλα.
     */
    @Transactional
    public void rejectPerformance(Long performanceId, String organizerUsername, String reason) {
        Performance p = performanceRepository.findById(performanceId)
                .orElseThrow(() -> new IllegalArgumentException("Performance not found"));
        Festival f = p.getFestival();

        if (!roleRepository.findByFestivalAndUsernameAndRoleType(f, organizerUsername, RoleType.ORGANIZER).isPresent())
            throw new SecurityException("Only organizers can reject");
        if (!(f.getState() == FestivalState.SCHEDULING || f.getState() == FestivalState.DECISION))
            throw new IllegalStateException("Cannot reject in current state");

        p.setStatus(PerformanceStatus.REJECTED);
        performanceRepository.save(p);

        // Για απλοποίηση ο λόγος εκτυπώνεται στην κονσόλα
        System.out.println("Performance " + p.getId() + " rejected: " + reason);
    }

    /**
     * Τελική υποβολή performance από καλλιτέχνη.
     * Το φεστιβάλ πρέπει να είναι σε FINAL_SUBMISSION state.
     */
    @Transactional
    public void finalSubmit(Long performanceId, String username, Performance finalVersion) {
        Performance p = performanceRepository.findById(performanceId)
                .orElseThrow(() -> new IllegalArgumentException("Performance not found"));
        Festival f = p.getFestival();

        if (f.getState() != FestivalState.FINAL_SUBMISSION)
            throw new IllegalStateException("Festival not in FINAL_SUBMISSION state");
        if (!p.getMainArtistUsername().equals(username) && (p.getBandMembers()==null || !p.getBandMembers().contains(username)))
            throw new SecurityException("Only artists can final submit");

        // Εφαρμογή τελικών αλλαγών και ορισμός κατάστασης FINAL_SUBMITTED
        updatePerformance(performanceId, username, finalVersion);
        p.setStatus(PerformanceStatus.FINAL_SUBMITTED);
        performanceRepository.save(p);
    }

    /**
     * Αποδοχή performance από οργανωτή.
     * Το φεστιβάλ πρέπει να είναι σε DECISION state.
     */
    @Transactional
    public void acceptPerformance(Long performanceId, String organizerUsername) {
        Performance p = performanceRepository.findById(performanceId)
                .orElseThrow(() -> new IllegalArgumentException("Performance not found"));
        Festival f = p.getFestival();

        if (!roleRepository.findByFestivalAndUsernameAndRoleType(f, organizerUsername, RoleType.ORGANIZER).isPresent())
            throw new SecurityException("Only organizers can accept");
        if (f.getState() != FestivalState.DECISION) throw new IllegalStateException("Festival not in DECISION state");

        p.setStatus(PerformanceStatus.ACCEPTED);
        performanceRepository.save(p);
    }
}
